# Mon Budget Famille 2026

Application web progressive conçue pour une utilisation quotidienne sur iPhone.

## Fonctions
- comptes multiples ;
- revenus et dépenses ;
- virements ;
- charges et revenus récurrents ;
- prévision du solde ;
- calendrier mensuel ;
- enveloppes budgétaires ;
- objectifs d’épargne ;
- méthode 50/30/20 ;
- recherche et favoris ;
- sauvegarde et restauration JSON ;
- fonctionnement hors connexion.

## Mise en ligne avec GitHub Pages
1. Créer un dépôt public nommé `mon-budget-famille-2026`.
2. Envoyer tout le contenu de ce dossier à la racine du dépôt.
3. Ouvrir `Settings` puis `Pages`.
4. Dans `Build and deployment`, choisir `Deploy from a branch`.
5. Sélectionner `main` et `/root`, puis enregistrer.
6. Ouvrir le lien GitHub Pages dans Safari.
7. Dans Safari, toucher Partager puis `Sur l’écran d’accueil`.

## Données
Les données sont conservées localement dans Safari. Utiliser régulièrement la fonction d’export de sauvegarde.
