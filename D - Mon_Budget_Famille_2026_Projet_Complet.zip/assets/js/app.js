const CATEGORIES=["Alimentation","Maison","Voiture","Santé","Enfants","Loisirs","Factures","Salaire","Aides","Épargne","Divers"];
const NEEDS=["Alimentation","Maison","Voiture","Santé","Enfants","Factures"];
const WANTS=["Loisirs","Divers"];
const KEY="budget_famille_2026";
const LEGACY_KEYS=["budget_famille_iphone_v3","budget_famille_iphone_v2"];
const DEFAULT_DATA={
  accounts:[{id:1,name:"Compte courant",initialBalance:0}],
  operations:[],
  fixedCharges:[],
  budgets:{},
  goals:[],
  favorites:[
    {id:1,label:"Courses",category:"Alimentation",type:"expense"},
    {id:2,label:"Essence",category:"Voiture",type:"expense"}
  ]
};
let data=load();

function clone(v){return JSON.parse(JSON.stringify(v))}
function load(){
  try{
    let raw=localStorage.getItem(KEY);
    if(!raw){
      for(const oldKey of LEGACY_KEYS){
        raw=localStorage.getItem(oldKey);
        if(raw) break;
      }
    }
    const parsed=raw?JSON.parse(raw):{};
    return {
      accounts:parsed.accounts||clone(DEFAULT_DATA.accounts),
      operations:parsed.operations||[],
      fixedCharges:parsed.fixedCharges||[],
      budgets:parsed.budgets||{},
      goals:parsed.goals||[],
      favorites:parsed.favorites||clone(DEFAULT_DATA.favorites)
    };
  }catch(e){return clone(DEFAULT_DATA)}
}
function save(){localStorage.setItem(KEY,JSON.stringify(data));renderAll()}
function euro(v){return new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR"}).format(Number(v)||0)}
function todayISO(){return new Date().toISOString().slice(0,10)}
function currentYM(){const n=new Date();return `${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,"0")}`}
function isCurrentMonth(s){return String(s).slice(0,7)===currentYM()}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]))}
function accountNameById(id){return data.accounts.find(a=>a.id===id)?.name||"Compte supprimé"}
function dateFR(s){return new Date(s+"T12:00:00").toLocaleDateString("fr-FR")}
function el(id){return document.getElementById(id)}

function accountBalanceFor(id){
  const a=data.accounts.find(x=>x.id===id); if(!a)return 0;
  return Number(a.initialBalance||0)+data.operations.filter(o=>o.accountId===id).reduce((s,o)=>s+(o.type==="income"?o.amount:-o.amount),0)
}

function generateRecurringForCurrentMonth(){
  const ym=currentYM();
  data.fixedCharges.forEach(f=>{
    const key=`${f.id}-${ym}`;
    if(data.operations.some(o=>o.recurringKey===key)) return;
    const maxDay=new Date(Number(ym.slice(0,4)),Number(ym.slice(5,7)),0).getDate();
    const day=Math.min(Number(f.day),maxDay);
    data.operations.push({
      id:Date.now()+Math.random(),type:f.type||"expense",amount:Number(f.amount),label:f.label,
      category:f.category||"Factures",accountId:Number(f.accountId),
      date:`${ym}-${String(day).padStart(2,"0")}`,recurringKey:key,generated:true
    });
  });
}

function addOperation(){
  const type=el("opType").value,amount=parseFloat(el("opAmount").value),label=el("opLabel").value.trim(),
  category=el("opCategory").value,accountId=Number(el("opAccount").value),date=el("opDate").value||todayISO();
  if(!label)return alert("Indiquez un libellé.");
  if(!amount||amount<=0)return alert("Indiquez un montant valide.");
  if(!accountId)return alert("Ajoutez d’abord un compte.");
  data.operations.unshift({id:Date.now(),type,amount,label,category,accountId,date});
  el("opAmount").value="";el("opLabel").value="";el("opDate").value=todayISO();save();alert("Opération ajoutée.");
}
function deleteOperation(id){if(confirm("Supprimer cette opération ?")){data.operations=data.operations.filter(o=>o.id!==id);save()}}

function addTransfer(){
  const from=Number(el("transferFrom").value),to=Number(el("transferTo").value),amount=parseFloat(el("transferAmount").value),date=el("transferDate").value||todayISO();
  if(!from||!to||from===to)return alert("Choisissez deux comptes différents.");
  if(!amount||amount<=0)return alert("Indiquez un montant valide.");
  const transferId=Date.now();
  data.operations.unshift(
    {id:transferId,type:"expense",amount,label:"Virement sortant",category:"Épargne",accountId:from,date,transferId},
    {id:transferId+1,type:"income",amount,label:"Virement entrant",category:"Épargne",accountId:to,date,transferId}
  );
  el("transferAmount").value="";save();alert("Virement enregistré.");
}

function addAccount(){
  const name=el("accountName").value.trim(),bal=parseFloat(el("accountBalance").value);
  if(!name)return alert("Indiquez un nom.");
  data.accounts.push({id:Date.now(),name,initialBalance:Number.isNaN(bal)?0:bal});
  el("accountName").value="";el("accountBalance").value="";save();
}
function deleteAccount(id){
  if(data.accounts.length===1)return alert("Il faut conserver au moins un compte.");
  if(data.operations.some(o=>o.accountId===id))return alert("Ce compte contient des opérations. Supprimez-les d’abord.");
  if(confirm("Supprimer ce compte ?")){data.accounts=data.accounts.filter(a=>a.id!==id);save()}
}

function addFixedCharge(){
  const label=el("fixedLabel").value.trim(),amount=parseFloat(el("fixedAmount").value),day=parseInt(el("fixedDay").value,10),
  accountId=Number(el("fixedAccount").value),type=el("fixedType").value,category=el("fixedCategory").value;
  if(!label||!amount||amount<=0||!day||day<1||day>31)return alert("Vérifiez le nom, le montant et le jour.");
  data.fixedCharges.push({id:Date.now(),label,amount,day,accountId,type,category});
  el("fixedLabel").value="";el("fixedAmount").value="";el("fixedDay").value="";
  generateRecurringForCurrentMonth();save()
}
function deleteFixed(id){if(confirm("Supprimer cette charge récurrente ?")){data.fixedCharges=data.fixedCharges.filter(x=>x.id!==id);save()}}

function addFavorite(){
  const label=el("favLabel").value.trim(),category=el("favCategory").value,type=el("favType").value;
  if(!label)return alert("Indiquez un libellé.");
  data.favorites.push({id:Date.now(),label,category,type});el("favLabel").value="";save()
}
function useFavorite(id){
  const f=data.favorites.find(x=>x.id===id);if(!f)return;
  el("opLabel").value=f.label;el("opCategory").value=f.category;el("opType").value=f.type;
  showPage("add",document.querySelectorAll("nav button")[1]);el("opAmount").focus()
}
function deleteFavorite(id){data.favorites=data.favorites.filter(x=>x.id!==id);save()}

function saveBudget(){
  const c=el("budgetCategory").value,a=parseFloat(el("budgetAmount").value);
  if(!a||a<=0)return alert("Indiquez un montant valide.");
  data.budgets[c]=a;el("budgetAmount").value="";save()
}

function addGoal(){
  const name=el("goalName").value.trim(),target=parseFloat(el("goalTarget").value),date=el("goalDate").value;
  if(!name||!target||target<=0)return alert("Indiquez un nom et un montant.");
  data.goals.push({id:Date.now(),name,target,current:0,date});
  el("goalName").value="";el("goalTarget").value="";el("goalDate").value="";save()
}
function deleteGoal(id){if(confirm("Supprimer cet objectif ?")){data.goals=data.goals.filter(g=>g.id!==id);save()}}
function addGoalContribution(){
  const id=Number(el("goalSelect").value),amount=parseFloat(el("goalContribution").value),g=data.goals.find(x=>x.id===id);
  if(!g)return alert("Créez d’abord un objectif.");
  if(!amount||amount<=0)return alert("Indiquez un montant valide.");
  g.current=Number(g.current||0)+amount;el("goalContribution").value="";save()
}

function opHTML(o){
  const sign=o.type==="income"?"+":"−",cls=o.type==="income"?"positive":"negative",badge=o.generated?` <span class="pill">auto</span>`:"";
  return `<div class="operation"><div class="meta"><strong>${esc(o.label)}${badge}</strong><small>${esc(o.category)} · ${esc(accountNameById(o.accountId))} · ${dateFR(o.date)}</small></div><div style="text-align:right"><div class="amount ${cls}">${sign}${euro(o.amount)}</div><button class="tiny danger" onclick="deleteOperation(${o.id})">Supprimer</button></div></div>`
}

function renderHome(){
  const total=data.accounts.reduce((s,a)=>s+accountBalanceFor(a.id),0),month=data.operations.filter(o=>isCurrentMonth(o.date));
  const inc=month.filter(o=>o.type==="income").reduce((s,o)=>s+o.amount,0),exp=month.filter(o=>o.type==="expense").reduce((s,o)=>s+o.amount,0),today=todayISO();
  const futureNet=month.filter(o=>o.date>today).reduce((s,o)=>s+(o.type==="income"?o.amount:-o.amount),0);
  el("totalBalance").textContent=euro(total);el("forecastBalance").textContent=euro(total+futureNet);el("monthIncome").textContent=euro(inc);el("monthExpense").textContent=euro(exp);
  el("homeAccounts").innerHTML=data.accounts.map(a=>`<div class="account"><div><strong>${esc(a.name)}</strong><br><small>Solde actuel</small></div><strong>${euro(accountBalanceFor(a.id))}</strong></div>`).join("");
  el("recentOperations").innerHTML=data.operations.length?[...data.operations].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5).map(opHTML).join(""):`<div class="empty">Aucune opération</div>`;
  let running=total;
  const upcoming=[...month].filter(o=>o.date>=today).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,8);
  el("forecastList").innerHTML=upcoming.length?upcoming.map(o=>{
    if(o.date>today)running+=o.type==="income"?o.amount:-o.amount;
    return `<div class="forecast-line"><div><strong>${dateFR(o.date)} · ${esc(o.label)}</strong><br><small>${esc(accountNameById(o.accountId))}</small></div><div style="text-align:right"><div class="${o.type==="income"?"positive":"negative"}">${o.type==="income"?"+":"−"}${euro(o.amount)}</div><small>Prévu ${euro(running)}</small></div></div>`
  }).join(""):`<div class="empty">Aucune opération à venir</div>`;
}
function renderOperations(){
  const q=(el("searchInput").value||"").toLowerCase().trim();
  const list=[...data.operations].sort((a,b)=>b.date.localeCompare(a.date)).filter(o=>!q||[o.label,o.category,accountNameById(o.accountId)].join(" ").toLowerCase().includes(q));
  el("allOperations").innerHTML=list.length?list.map(opHTML).join(""):`<div class="empty">Aucune opération trouvée</div>`;
}
function renderCalendar(){
  const list=[...data.operations].filter(o=>isCurrentMonth(o.date)).sort((a,b)=>a.date.localeCompare(b.date));
  el("calendarList").innerHTML=list.length?list.map(o=>`<div class="calendar-item"><div class="day-badge">${o.date.slice(8,10)}</div><div class="meta"><strong>${esc(o.label)}</strong><small>${esc(o.category)} · ${esc(accountNameById(o.accountId))}</small></div><strong class="${o.type==="income"?"positive":"negative"}">${o.type==="income"?"+":"−"}${euro(o.amount)}</strong></div>`).join(""):`<div class="empty">Aucune opération ce mois-ci</div>`;
}
function renderBudgets(){
  const expenses=data.operations.filter(o=>o.type==="expense"&&isCurrentMonth(o.date));
  const rows=CATEGORIES.filter(c=>data.budgets[c]).map(c=>{
    const spent=expenses.filter(o=>o.category===c).reduce((s,o)=>s+o.amount,0),limit=data.budgets[c],pct=Math.min(100,Math.round(spent/limit*100)),cls=pct>=100?"over":pct>=80?"warn":"";
    return `<div class="budget-row" style="display:block"><div class="progress-label"><strong>${esc(c)}</strong><span>${euro(spent)} / ${euro(limit)}</span></div><div class="bar ${cls}"><span style="width:${pct}%"></span></div></div>`
  });
  el("budgetRows").innerHTML=rows.length?rows.join(""):`<div class="empty">Aucune enveloppe définie</div>`;
}
function renderGoals(){
  el("goalsList").innerHTML=data.goals.length?data.goals.map(g=>{
    const pct=Math.min(100,Math.round((Number(g.current||0)/Number(g.target))*100));
    return `<div class="goal-row" style="display:block"><div class="progress-label"><strong>${esc(g.name)}</strong><span>${euro(g.current)} / ${euro(g.target)}</span></div><div class="bar"><span style="width:${pct}%"></span></div><div class="progress-label" style="margin-top:6px"><span>${g.date?`Objectif ${dateFR(g.date)}`:"Sans date"}</span><button class="tiny danger" onclick="deleteGoal(${g.id})">Supprimer</button></div></div>`
  }).join(""):`<div class="empty">Aucun objectif d’épargne</div>`;
  el("goalSelect").innerHTML=data.goals.map(g=>`<option value="${g.id}">${esc(g.name)}</option>`).join("");
}
function renderMethod(){
  const month=data.operations.filter(o=>isCurrentMonth(o.date)),income=month.filter(o=>o.type==="income").reduce((s,o)=>s+o.amount,0);
  const needs=month.filter(o=>o.type==="expense"&&NEEDS.includes(o.category)).reduce((s,o)=>s+o.amount,0);
  const wants=month.filter(o=>o.type==="expense"&&WANTS.includes(o.category)).reduce((s,o)=>s+o.amount,0);
  const savings=month.filter(o=>o.type==="expense"&&o.category==="Épargne").reduce((s,o)=>s+o.amount,0);
  const line=(name,val,target)=>{const pct=income?Math.round(val/income*100):0;return `<div class="budget-row" style="display:block"><div class="progress-label"><strong>${name}</strong><span>${pct}% · cible ${target}%</span></div><div class="bar ${pct>target+10?"over":pct>target?"warn":""}"><span style="width:${Math.min(100,pct)}%"></span></div><small>${euro(val)}</small></div>`};
  el("methodSummary").innerHTML=income?line("Besoins",needs,50)+line("Envies",wants,30)+line("Épargne",savings,20):`<div class="empty">Ajoutez vos revenus du mois pour voir la répartition.</div>`;
}
function renderSettings(){
  el("accountsList").innerHTML=data.accounts.map(a=>`<div class="account"><div><strong>${esc(a.name)}</strong><br><small>Départ : ${euro(a.initialBalance)}</small></div><button class="tiny danger" onclick="deleteAccount(${a.id})">Supprimer</button></div>`).join("");
  el("fixedList").innerHTML=data.fixedCharges.length?[...data.fixedCharges].sort((a,b)=>a.day-b.day).map(x=>`<div class="fixed"><div><strong>${esc(x.label)}</strong><br><small>Le ${x.day} · ${x.type==="income"?"Revenu":"Dépense"} · ${esc(accountNameById(x.accountId))}</small></div><div style="text-align:right"><strong>${euro(x.amount)}</strong><br><button class="tiny danger" onclick="deleteFixed(${x.id})">Supprimer</button></div></div>`).join(""):`<div class="empty">Aucune opération récurrente</div>`;
  el("favoritesList").innerHTML=data.favorites.length?data.favorites.map(f=>`<div class="favorite"><div><strong>${esc(f.label)}</strong><br><small>${esc(f.category)} · ${f.type==="income"?"Revenu":"Dépense"}</small></div><button class="tiny danger" onclick="deleteFavorite(${f.id})">Supprimer</button></div>`).join(""):`<div class="empty">Aucun favori</div>`;
  el("favoritesQuick").innerHTML=data.favorites.length?data.favorites.map(f=>`<button class="secondary" onclick="useFavorite(${f.id})">${esc(f.label)}</button>`).join(""):`<div class="empty">Aucun favori</div>`;
}
function renderChart(){
  const canvas=el("expenseChart"),ctx=canvas.getContext("2d");ctx.clearRect(0,0,canvas.width,canvas.height);
  const month=data.operations.filter(o=>o.type==="expense"&&isCurrentMonth(o.date));
  const totals=CATEGORIES.map(c=>({c,v:month.filter(o=>o.category===c).reduce((s,o)=>s+o.amount,0)})).filter(x=>x.v>0).sort((a,b)=>b.v-a.v).slice(0,6);
  if(!totals.length){ctx.font="16px sans-serif";ctx.fillText("Aucune dépense ce mois-ci",20,40);return}
  const max=Math.max(...totals.map(x=>x.v));
  totals.forEach((x,i)=>{const y=18+i*38,w=(x.v/max)*(canvas.width-220);ctx.fillStyle="#1f6f5f";ctx.fillRect(150,y,w,20);ctx.fillStyle="#1f2d29";ctx.font="14px sans-serif";ctx.fillText(x.c,10,y+15);ctx.fillText(euro(x.v),160+w,y+15)});
}
function fillSelects(){
  [el("opCategory"),el("budgetCategory"),el("favCategory"),el("fixedCategory")].forEach(sel=>{const cur=sel.value;sel.innerHTML=CATEGORIES.map(c=>`<option>${c}</option>`).join("");if(cur)sel.value=cur});
  [el("opAccount"),el("fixedAccount"),el("transferFrom"),el("transferTo")].forEach(sel=>{const cur=sel.value;sel.innerHTML=data.accounts.map(a=>`<option value="${a.id}">${esc(a.name)}</option>`).join("");if(cur)sel.value=cur});
}
function renderAll(){fillSelects();renderHome();renderOperations();renderCalendar();renderBudgets();renderGoals();renderMethod();renderSettings();renderChart()}
function showPage(id,btn){
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  document.querySelectorAll("nav button").forEach(b=>b.classList.remove("active"));
  el(id).classList.add("active");btn.classList.add("active");window.scrollTo({top:0,behavior:"smooth"});
  if(id==="operations")setTimeout(renderChart,50)
}
function showSub(id,btn){
  const parent=btn.closest("section");parent.querySelectorAll(".subpage").forEach(p=>p.classList.remove("active"));
  btn.parentElement.querySelectorAll("button").forEach(b=>b.classList.remove("active"));
  el(id).classList.add("active");btn.classList.add("active");if(id==="chartBox")setTimeout(renderChart,50)
}
function exportData(){
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),a=document.createElement("a");
  a.href=URL.createObjectURL(blob);a.download="sauvegarde-budget-famille-2026.json";a.click();URL.revokeObjectURL(a.href)
}
function importData(e){
  const file=e.target.files[0];if(!file)return;
  const reader=new FileReader();reader.onload=()=>{try{data=JSON.parse(reader.result);save();alert("Sauvegarde restaurée.")}catch{alert("Fichier invalide.")}};reader.readAsText(file)
}
function resetAll(){if(confirm("Effacer toutes les données ?")){data=clone(DEFAULT_DATA);save()}}

el("monthLabel").textContent=new Date().toLocaleDateString("fr-FR",{month:"long",year:"numeric"}).replace(/^./,c=>c.toUpperCase());
el("opDate").value=todayISO();el("transferDate").value=todayISO();
generateRecurringForCurrentMonth();
if("serviceWorker"in navigator)navigator.serviceWorker.register("service-worker.js").catch(()=>{});
save();